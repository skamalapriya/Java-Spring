package com.code.entity;

public interface Coach{
	public String getDailyWorkOut();
	public String getDailyFortune();
}
