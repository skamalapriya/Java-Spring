package com.code.service;

public interface IFortune {
	public String getDailyFortune();
}
