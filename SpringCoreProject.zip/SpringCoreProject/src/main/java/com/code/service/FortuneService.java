package com.code.service;

public class FortuneService implements IFortune{

	@Override
	public String getDailyFortune() {
		// TODO Auto-generated method stub
		return "Today is a good day";
	}

}
